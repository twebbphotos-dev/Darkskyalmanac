/* ════════════════════════════════════════════════════════════
   Zion Dark Sky Almanac — Service Worker v50
   Two-point calibration solver rewritten (angular separation, not compass residual); Reset to defaults button.
   ════════════════════════════════════════════════════════════ */
const CACHE = 'zion-sky-v62k';

const APP_SHELL = [
  // Extensionless URLs so the same SW works on Cloudflare Workers (which
  // strips .html) and on Netlify (which serves both forms). Root './' covers
  // the index page at /.
  './','forecast','moon','constellations',
  'messier','finder','solar','settings',
  'jupiter','earth','mars','saturn','darksky','events','objects',
  // Regional dark-sky maps — precached so "Add to Home Screen" really does
  // give the user the whole app offline, including these planning pages.
  '0-INDEX-dark-sky-maps',
  'brycecanyon-prototype','capitolreef-prototype',
  'cedarbreaks-prototype','escalante-prototype',
  'grandcanyon-prototype','kanab-prototype',
  'zion-map.jpg',
  'manifest.json','icon-180.png','icon-192.png','icon-512.png',
  'https://cdnjs.cloudflare.com/ajax/libs/suncalc/1.9.0/suncalc.min.js',
  'https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600&display=swap'
];

self.addEventListener('install',function(e){
  self.skipWaiting();
  e.waitUntil(caches.open(CACHE).then(function(c){
    return Promise.all(APP_SHELL.map(function(url){
      return c.add(url).catch(function(){ console.log('skip cache',url); });
    }));
  }));
});

self.addEventListener('activate',function(e){
  e.waitUntil(caches.keys().then(function(keys){
    return Promise.all(keys.filter(function(k){return k!==CACHE;}).map(function(k){return caches.delete(k);}));
  }).then(function(){return self.clients.claim();}));
});

self.addEventListener('fetch',function(e){
  const url=e.request.url;
  if(e.request.method!=='GET') return;
  if(url.indexOf('open-meteo.com')!==-1||url.indexOf('zippopotam.us')!==-1){
    e.respondWith(fetch(e.request).then(function(r){
      const c=r.clone();
      caches.open(CACHE).then(function(cache){cache.put(e.request,c);});
      return r;
    }).catch(function(){return caches.match(e.request);}));
    return;
  }
  // NOAA space-weather (aurora Kp): always network-first so the forecast is
  // current; keep the latest copy only as an offline fallback.
  if(url.indexOf('services.swpc.noaa.gov')!==-1){
    e.respondWith(fetch(e.request).then(function(r){
      const c=r.clone();
      caches.open(CACHE).then(function(cache){cache.put(e.request,c);});
      return r;
    }).catch(function(){return caches.match(e.request);}));
    return;
  }
  e.respondWith(caches.match(e.request).then(function(cached){
    if(cached) return cached;
    return fetch(e.request).then(function(r){
      if(r&&r.status===200){const c=r.clone();caches.open(CACHE).then(function(cache){cache.put(e.request,c);});}
      return r;
    }).catch(function(){
      if(e.request.mode==='navigate') return caches.match('./');
    });
  }));
});
