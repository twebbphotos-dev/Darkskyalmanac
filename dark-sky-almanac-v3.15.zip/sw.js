/* ════════════════════════════════════════════════════════════
   Dark Sky Almanac — Service Worker
   v118: bulletproof offline. Every page, image, font, and library
   is precached so the app works fully offline once installed via
   "Add to Home Screen". Fonts and the SunCalc library are fetched
   AND their sub-resources (the .woff2 files the font CSS points to)
   are cached too, so type renders correctly with no network.
   ════════════════════════════════════════════════════════════ */
const CACHE = 'zion-sky-v281';
// ── CRITICAL same-origin shell ──────────────────────────────────
// Everything the app itself is made of, in the form that ALWAYS resolves on
// every host (real files: index.html, *.html, images, icons). If ANY of these
// fail to cache during install we fail the install and let the browser retry,
// rather than silently shipping a half-broken offline app.
const CRITICAL = [
  './',
  'index.html',
  'forecast.html','clouds.html','moon.html','objects.html','constellations.html','catalog.html',
  'solar.html','jupiter.html','saturn.html','mars.html','earth.html',
  'mercury.html','venus.html','uranus.html','neptune.html','pluto.html',
  'events.html','finder.html','daylight.html','tonight.html','settings.html','maps.html',
  // 3D spacecraft pages (their text works offline; the 3D view itself needs the optional download below)
  'spacecraft.html','voyager.html',
  // Astrophotography tools
  'photography.html','npf.html','session-log.html','integration.html','meridian.html',
  'map-zion.html','map-bryce.html','map-cedar-breaks.html','map-st-george.html',
  'map-capitol-reef.html','map-canyonlands.html','map-arches.html',
  // Map basemaps
  'map-zion.jpg','map-bryce.jpg','map-cedar-breaks.jpg','map-st-george.jpg',
  'map-capitol-reef.jpg','map-canyonlands.jpg','map-arches.jpg',
  // Shared engine loaded by every map page (v123 refactor — was inlined per page)
  'map-engine.js',
  // Shared UI: themed date picker used across the app
  'zcl-calendar.js',
  // Shared timezone resolver — every page renders sun/moon times through this,
  // so it must be present offline or the app has no clock at all.
  'zcl-tz.js',
  // SunCalc, self-hosted so sunrise/moonrise never wait on a CDN
  'suncalc.min.js',
  // Saturn ring geometry + moon positions (Meeus ch. 45-46), used by saturn.html
  'saturn-ephem.js',
  'jupiter-ephem.js',
  'zcl-season.js',
  // Planet & moon imagery
  'img/jupiter.jpg','img/io.jpg','img/europa.jpg','img/ganymede.jpg','img/callisto.jpg',
  'img/mars.jpg','img/saturn.jpg','img/earth.jpg','img/moon.jpg',
  // PWA shell
  'manifest.json','icon-180.png','icon-192.png','icon-512.png','icon.svg','social.png',
  'robots.txt','sitemap.xml'
];
// ── Extensionless aliases ───────────────────────────────────────
// Cloudflare Workers strips ".html"; many internal links use the extensionless
// form ('forecast' not 'forecast.html'). We cache these too so offline nav to
// either form works — but BEST-EFFORT, because on a host that doesn't serve the
// extensionless form they'd 404 and (if they were in CRITICAL's atomic addAll)
// would wrongly fail the whole install. The fetch handler also normalises
// .html ⇄ extensionless on cache miss as a second safety net.
const ALIASES = [
  'forecast','clouds','moon','objects','constellations','catalog',
  'solar','jupiter','saturn','mars','earth',
  'mercury','venus','uranus','neptune','pluto',
  'events','finder','daylight','tonight','settings','maps','spacecraft','voyager',
  'photography','npf','session-log','integration','meridian',
  'map-zion','map-bryce','map-cedar-breaks','map-st-george',
  'map-capitol-reef','map-canyonlands','map-arches'
];
// ── Optional 3D download ────────────────────────────────────────
// The 3D viewers (three.js bundles, spacecraft models, comparison photos) are
// about 20 MB, so they are NOT part of the normal offline install. They are
// saved only when the user taps "Download everything" in Settings, into their
// own cache that survives app updates (so an update never throws 20 MB away).
// After an update, only files that actually changed are fetched again.
const C3D = 'zion-sky-3d';
const OFFLINE3D = [
  'spacecraft.bundle.js','voyager.bundle.js',
  'models/apollo.glb', 'models/cassini.glb', 'models/curiosity.glb', 'models/earth-leo-clouds.jpg',
  'models/earth-leo.jpg', 'models/hubble.glb', 'models/ingenuity.glb', 'models/iss.glb',
  'models/jwst.glb', 'models/lm.glb', 'models/lrv.glb', 'models/moon-a17.bin',
  'models/perseverance.glb', 'models/shuttle.glb', 'models/voyager1.glb',
  'img/cmp/carina-hubble.jpg', 'img/cmp/carina-webb.jpg', 'img/cmp/deep-field-hubble.jpg',
  'img/cmp/deep-field-webb.jpg', 'img/cmp/pillars-hubble.jpg', 'img/cmp/pillars-webb.jpg',
  'img/cmp/southern-ring-hubble.jpg', 'img/cmp/southern-ring-webb.jpg',
  'img/a17-flag.jpg'
];
// Is our saved copy the same file the server has now? (ETag where the host
// sends one, otherwise size + date.)
function sameFile(a, b){
  const ea = (a.headers.get('etag') || '').replace(/^W\//, ''), eb = (b.headers.get('etag') || '').replace(/^W\//, '');
  if(ea && eb) return ea === eb;
  return a.headers.get('content-length') === b.headers.get('content-length') && a.headers.get('last-modified') === b.headers.get('last-modified');
}
// Bring an existing 3D download up to date: fetch what is missing or changed.
async function refresh3d(){
  if(!(await caches.has(C3D))) return;          // never downloaded: leave it that way
  const c = await caches.open(C3D);
  for(const u of OFFLINE3D){
    try{
      const have = await c.match(u);
      if(have){ const h = await fetch(u, { method:'HEAD', cache:'no-store' }); if(!h.ok || sameFile(have, h)) continue; }
      const r = await fetch(u, { cache:'reload' });
      if(r && r.ok) await c.put(u, r);
    }catch(e){ /* offline or flaky — the fetch handler refreshes files as they are used */ }
  }
}
// ── External libraries / fonts ──────────────────────────────────
// Cached best-effort at install (network may be flaky), then BACKFILLED on
// first use by the fetch handler so they end up cached no matter what. The
// two font CSS variants differ only by the 700 weight (map pages use it).
const EXTERNAL = [
  'https://cdnjs.cloudflare.com/ajax/libs/suncalc/1.9.0/suncalc.min.js',
  'https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600&display=swap',
  'https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&display=swap'
];
// Pull the actual font files (.woff2) referenced inside a Google Fonts CSS
// response and cache them, so type renders offline. Without this, the CSS is
// cached but points at uncached gstatic URLs and the font silently falls back.
async function cacheFontFiles(cache, cssURL){
  try{
    const res = await fetch(cssURL, { mode:'cors' });
    if(!res || !res.ok) return;
    await cache.put(cssURL, res.clone());
    const css = await res.text();
    const urls = (css.match(/https:\/\/fonts\.gstatic\.com\/[^)]+\.woff2/g) || []);
    await Promise.all(urls.map(u =>
      fetch(u).then(r => r && r.ok ? cache.put(u, r) : null).catch(()=>{})
    ));
  }catch(e){ /* offline at install — fetch handler will backfill later */ }
}

self.addEventListener('install', function(e){
  self.skipWaiting();
  e.waitUntil((async function(){
    const cache = await caches.open(CACHE);
    // CRITICAL: must all succeed. addAll is atomic — if any 404s the whole
    // thing rejects and the SW install fails (so we don't ship a broken cache).
    // We add a couple of retries for transient network hiccups.
    let lastErr = null;
    for(let attempt=0; attempt<3; attempt++){
      try{ await cache.addAll(CRITICAL); lastErr = null; break; }
      catch(err){ lastErr = err; await new Promise(r=>setTimeout(r, 800)); }
    }
    if(lastErr) throw lastErr;   // fail the install; browser will retry later
    // ALIASES (extensionless URLs) + EXTERNAL libraries: best-effort, plus pull
    // the font sub-resources so type renders offline.
    await Promise.all([
      cacheFontFiles(cache, EXTERNAL[1]),
      cacheFontFiles(cache, EXTERNAL[2]),
      fetch(EXTERNAL[0]).then(r => r && r.ok ? cache.put(EXTERNAL[0], r) : null).catch(()=>{})
    ].concat(ALIASES.map(function(u){
      return cache.add(u).catch(function(){});   // ok if the host doesn't serve it
    })));
  })());
});

self.addEventListener('activate', function(e){
  e.waitUntil((async function(){
    const keys = await caches.keys();
    await Promise.all(keys.filter(k => k !== CACHE && k !== C3D).map(k => caches.delete(k)));
    await self.clients.claim();
    // Self-heal: after a long idle period a browser may have evicted part of the
    // cache. Whenever the SW activates, re-add any CRITICAL item that's gone
    // missing so the app stays fully offline-capable without the user having to
    // do anything. (Best-effort — needs network, runs only when something's
    // actually missing, so it's free on the normal path.)
    try{
      const cache = await caches.open(CACHE);
      const missing = [];
      await Promise.all(CRITICAL.map(async u => {
        const m = await cache.match(u, { ignoreSearch:true });
        if(!m) missing.push(u);
      }));
      if(missing.length) await cache.addAll(missing).catch(()=>{});
    }catch(e){ /* offline now — fetch handler will backfill on next online view */ }
    await refresh3d();
  })());
});
// Allow the page to ask the SW questions (e.g. "are you fully cached?") and to
// trigger a re-cache on demand from Settings.
self.addEventListener('message', function(e){
  const msg = e.data || {};
  if(msg.type === 'zcl-cache-status'){
    e.waitUntil((async function(){
      const cache = await caches.open(CACHE);
      const keys = await cache.keys();
      // Consider the app "offline-ready" when every CRITICAL item is present.
      let have = 0;
      await Promise.all(CRITICAL.map(async u => {
        const m = await cache.match(u, { ignoreSearch:true });
        if(m) have++;
      }));
      const ready = have >= CRITICAL.length;
      (e.source && e.source.postMessage) && e.source.postMessage({
        type:'zcl-cache-status-reply', ready, have, total:CRITICAL.length, cached:keys.length
      });
    })());
  } else if(msg.type === 'zcl-3d-list'){
    (e.source && e.source.postMessage) && e.source.postMessage({ type:'zcl-3d-list-reply', list:OFFLINE3D, cache:C3D });
  } else if(msg.type === 'zcl-recache'){
    e.waitUntil((async function(){
      const cache = await caches.open(CACHE);
      await cache.addAll(CRITICAL).catch(()=>{});
      await Promise.all([
        cacheFontFiles(cache, EXTERNAL[1]),
        cacheFontFiles(cache, EXTERNAL[2]),
        fetch(EXTERNAL[0]).then(r => r && r.ok ? cache.put(EXTERNAL[0], r) : null).catch(()=>{})
      ].concat(ALIASES.map(function(u){ return cache.add(u).catch(function(){}); })));
      (e.source && e.source.postMessage) && e.source.postMessage({ type:'zcl-recache-done' });
    })());
  }
});

// ── Weak-signal ("1 bar") handling ─────────────────────────────
// A phone with one bar isn't offline, so requests don't fail — they just
// hang. Every network wait below has a deadline; when it passes we serve
// the cached copy (and let the network finish in the background to refresh
// the cache for next time). Airplane mode and 1 bar now behave the same.
const PAGE_WAIT = 2000, DATA_WAIT = 7000, ASSET_WAIT = 4000;
function deadline(p, ms){
  return new Promise(function(res, rej){
    const t = setTimeout(function(){ rej(new Error('timeout')); }, ms);
    p.then(function(r){ clearTimeout(t); res(r); }, function(err){ clearTimeout(t); rej(err); });
  });
}
function putLater(req, r){ if(r && (r.status === 200 || r.type === 'opaque')){ const c = r.clone(); caches.open(CACHE).then(function(cache){ cache.put(req, c); }); } return r; }
function cachedPage(req, url){
  return caches.match(req, { ignoreSearch:true }).then(function(m){
    if(m) return m;
    var alt = /\.html$/.test(url) ? url.replace(/\.html$/, '') : url + '.html';
    return caches.match(alt, { ignoreSearch:true });
  });
}

self.addEventListener('fetch', function(e){
  const req = e.request;
  if(req.method !== 'GET') return;
  const url = req.url;
  // The 3D spacecraft viewers: models and three.js bundles (about 20 MB) are
  // only kept if the user chose "Download everything". If they did: offline
  // we serve the saved copy; online we take the network (so an updated model
  // is never mixed with an old one), refresh the saved copy, and fall back
  // to it on a weak signal. If they didn't: plain network, nothing stored.
  if(/\/models\/|\.bundle\.js/.test(url)){
    e.respondWith(caches.has(C3D).then(function(has){
      if(!has) return fetch(req);
      return caches.open(C3D).then(function(c){
        return c.match(req, { ignoreSearch:true }).then(function(hit){
          if(!hit) return fetch(req);
          if(self.navigator && self.navigator.onLine === false) return hit;
          const net = fetch(req).then(function(r){ if(r && r.status === 200) c.put(req, r.clone()); return r; });
          try{ e.waitUntil(net.catch(function(){})); }catch(err){}
          return deadline(net, ASSET_WAIT).then(function(r){ return (r && r.ok) ? r : hit; }, function(){ return hit; });
        });
      });
    }));
    return;
  }

  // Live data (weather, aurora): try the network for a few seconds, then
  // fall back to the last copy we saved.
  if(url.indexOf('open-meteo.com')   !== -1 ||
     url.indexOf('zippopotam.us')    !== -1 ||
     url.indexOf('services.swpc.noaa.gov') !== -1){
    const net = fetch(req).then(function(r){ return putLater(req, r); });
    e.waitUntil(net.catch(function(){}));
    e.respondWith(
      deadline(net, DATA_WAIT).catch(function(){
        return caches.match(req).then(function(m){
          return m || new Response('{"offline":true}', { status: 503, headers: { 'Content-Type': 'application/json' } });
        });
      })
    );
    return;
  }

  // App pages: fresh from the network when it answers quickly, otherwise the
  // cached page right away. The slow network reply still updates the cache.
  if(req.mode === 'navigate' || req.destination === 'document'){
    const net = fetch(req).then(function(r){ return putLater(req, r); });
    e.waitUntil(net.catch(function(){}));
    e.respondWith(
      cachedPage(req, url).then(function(cached){
        if(!cached) return net.catch(function(){ return caches.match('index.html') || caches.match('./'); });
        if(self.navigator && self.navigator.onLine === false) return cached;
        return deadline(net, PAGE_WAIT).then(function(r){ return (r && r.ok) ? r : cached; }, function(){ return cached; });
      })
    );
    return;
  }

  // Everything else (images, fonts, libraries, css): cache-first, and
  // BACKFILL anything not yet cached on first use. A cache miss on a weak
  // signal gives up after a few seconds instead of stalling the page — the
  // font stylesheet in particular blocks rendering until it answers.
  e.respondWith(
    caches.match(req, { ignoreSearch:true }).then(function(cached){
      if(cached) return cached;
      const net = fetch(req).then(function(r){ return putLater(req, r); });
      try{ e.waitUntil(net.catch(function(){})); }catch(err){}
      return deadline(net, url.indexOf('fonts.googleapis.com') !== -1 ? 1200 : ASSET_WAIT).catch(function(){
        if(url.indexOf('fonts.googleapis.com') !== -1){
          return caches.match(EXTERNAL[1]).then(function(m){ return m || caches.match(EXTERNAL[2]); })
            .then(function(m){ return m || new Response('', { headers: { 'Content-Type': 'text/css' } }); });
        }
        return Response.error();
      });
    })
  );
});
